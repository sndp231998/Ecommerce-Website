# Ecommerce-Website-using-PHP, Bootstrap4, Html5, Css3
Home Page
![](screenshot/home.PNG)

Shop
![](screenshot/shop1.PNG)

Cart
![](screenshot/cart.PNG)
![](screenshot/cart1.PNG)

Login
![](screenshot/login.PNG)

Signup

![](screenshot/signup.PNG)

Footer
![](screenshot/footer.PNG)

Payment

![](screenshot/payment.PNG)

Admin Dashboard
![](screenshot/admin_dashboard.PNG)


To login into admin panel goto localhost/admin_area/login.php

jayshreeram@gmail.com
231998

//admin
sandipchapagain797@gmail.com
231998

