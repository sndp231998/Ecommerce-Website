<div class="box">
    
    <center>
        
        <h3>Change Your Password</h3>
        
        
    </center>
    
    <div class="form-group">
        
        <label for="">Enter Your Current Password</label>
        <input type="password" name="old_password" class="form-control">
    </div>
    
    <div class="form-group">
        <label for="">Enter New Password</label>
        <input type="password" class="form-control" name="new_password">
    </div>
    
     <div class="form-group">
        <label for="">Confirm New Password</label>
        <input type="password" class="form-control" name="c_n_password">
    </div>
    
     <div class="text-center">
        <button class="btn btn-primary btn-lg">
            Update
        </button>
    </div>
    
</div>