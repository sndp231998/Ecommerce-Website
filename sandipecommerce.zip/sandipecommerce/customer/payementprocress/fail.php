<?php

echo "<h1> payement Failed";
//<a href="https://google.com"> Goto Homepage</a>
?>