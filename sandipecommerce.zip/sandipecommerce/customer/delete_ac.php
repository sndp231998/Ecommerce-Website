<div class="box">
    <center>
        
        <h1>Do you really want to delete your account</h1>
        
   
    
    <form action="" method="post">
        
        <input type="submit" name="yes" value="Yes, I want to delete" class="btn btn-danger">
         <input type="submit" name="no" value="No, I don't want to delete" class="btn btn-primary">
        
    </form>
    
     </center>
    
</div>