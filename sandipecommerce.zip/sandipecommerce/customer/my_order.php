
   <div class="box">

   <center>
    
    <h1>
        
        My Order
        
    </h1>
    
    <p>
        If you have any query please feel free to <a href="../contact.php">contact us </a> 
    </p>
    
</center>
<hr>

<div class="table-responsive">
    
    <table class="table table-bordered table-hover">
        
        <thead>
            
            <tr>
                <th>Sr No</th>
                 <th>Due Amount</th>
                  <th>Invoice Number</th>
                   <th>Quantity</th>
                    <th>Size</th>
                     <th>Order Date</th>
                      <th>paid/unpaid</th>
                       <th>Status</th>
            </tr>
            
        </thead>
        
        <tbody>
            <tr>
                <td>#1</td>
                 <td>9000 RS</td>
                  <td>1646564</td>
                   <td>2</td>
                    <td>Large</td>
                     <td>2020-1-12</td>
                      <td>Unpaid</td>
                     <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm If Paid</a></td> 
            </tr>
            
            <tr>
                <td>#2</td>
                 <td>7000 RS</td>
                  <td>103304</td>
                   <td>2</td>
                    <td>Large</td>
                     <td>2023-1-12</td>
                      <td>Unpaid</td>
                     <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm If Paid</a></td> 
            </tr>
            
            
            <tr>
                <td>#3</td>
                 <td>500 RS</td>
                  <td>26546564</td>
                   <td>2</td>
                    <td>Large</td>
                     <td>2023-1-12</td>
                      <td>Unpaid</td>
                     <td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm If Paid</a></td> 
            </tr>
        </tbody>
        
        
    </table>
    
    
</div>

</div>